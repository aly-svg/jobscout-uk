"""LLM steps: CV profiling, batch job scoring, letters, CV improvement advice."""
import json

from .llm import chat, extract_json, DemoLLM

BATCH = 8

SYSTEM = ("You are an expert UK IT recruitment analyst. You are precise, honest, and you "
          "always reply with VALID JSON only - no markdown, no commentary.")


def _use_demo(provider):
    return provider == "Demo (offline)"


# ------------------------------------------------------------- profiling ---

def build_profile(provider, api_key, model, cv_text, log):
    if _use_demo(provider):
        prof = DemoLLM(cv_text).profile()
        prof["_cv_text"] = cv_text
        log(f"  Profile built (demo). Target titles: {', '.join(prof['target_titles'])}")
        return prof
    user = f"""Read this CV and return JSON with EXACTLY these keys:
{{
 "summary": "8-line professional summary",
 "target_titles": ["4-6 job titles this person should search for in the UK"],
 "strengths": ["8-12 keywords/skills that sell this candidate"],
 "sponsorship_required": true/false (does the CV state a visa/sponsorship need?),
 "minimum_salary": integer (GBP, the realistic floor for this seniority; if sponsorship is
   required it must be at least the Skilled Worker going rate ~55000 for BA/PM roles)
}}

CV:
---
{cv_text[:9000]}
---"""
    data = extract_json(chat(provider, api_key, model, SYSTEM, user, max_tokens=1500, json_mode=True))
    # defensive defaults
    data.setdefault("target_titles", ["Business Analyst", "IT Project Manager"])
    data.setdefault("strengths", [])
    data.setdefault("sponsorship_required", False)
    data.setdefault("minimum_salary", 0)
    data["target_titles"] = [str(t) for t in data["target_titles"]][:6]
    data["_cv_text"] = cv_text
    log(f"  Profile built. Target titles: {', '.join(data['target_titles'])}")
    return data


# --------------------------------------------------------------- scoring ---

def _score_prompt(profile, batch):
    lines = []
    for i, j in enumerate(batch):
        lines.append(json.dumps({
            "i": i, "title": j["title"], "company": j["company"], "location": j["location"],
            "salary": j["salary"], "source": j["source"],
            "snippet": j["description"][:700],
        }, ensure_ascii=False))
    sponsorship_rule = ""
    if profile.get("sponsorship_required"):
        sponsorship_rule = (
            "\nIMPORTANT - the candidate NEEDS Skilled Worker sponsorship:\n"
            "- Large firms/consultancies/universities are far more likely to sponsor than SMEs.\n"
            "- If advertised salary is clearly below GBP 41,700, band must be 'Low' (not sponsorable).\n"
            "- Salaries below ~GBP 55,000 for BA/PM roles are below the occupation going rate: cap at 'Medium' and mention it in 'why'.\n"
            "- Day-rate contract roles cannot be sponsored: band 'Low', say why.\n")
    return f"""Candidate profile:
{json.dumps({k: profile.get(k) for k in ('summary', 'strengths', 'sponsorship_required', 'minimum_salary')}, ensure_ascii=False)}
{sponsorship_rule}
Score each job below for THIS candidate. Return a JSON array, one object per job:
{{"i": <index>, "score": 0-100, "band": "High"|"Medium"|"Low",
  "why": "<=25 words - the decisive reasons",
  "gaps": "<=20 words - what the CV lacks for this job (or 'None')"}}

Banding: High = apply this week (score>=70). Medium = worth applying with a tailored CV (45-69).
Low = weak use of time (<45). Be discriminating - do not cluster everything in Medium.

Jobs:
{chr(10).join(lines)}"""


def score_jobs(provider, api_key, model, profile, jobs, log, prog=None, base=55, span=27):
    if _use_demo(provider):
        demo = DemoLLM(profile.get("_cv_text") or profile.get("summary", ""))
        for j in jobs:
            j.update(demo.score(j))
        log(f"  Scored {len(jobs)} jobs (demo keyword engine)")
        return jobs

    for start in range(0, len(jobs), BATCH):
        batch = jobs[start:start + BATCH]
        try:
            arr = extract_json(chat(provider, api_key, model, SYSTEM,
                                    _score_prompt(profile, batch), max_tokens=2500, json_mode=True))
            if isinstance(arr, dict):  # some models wrap the array
                arr = arr.get("results") or arr.get("jobs") or []
            by_i = {int(o.get("i", -1)): o for o in arr if isinstance(o, dict)}
            for i, j in enumerate(batch):
                o = by_i.get(i, {})
                score = int(o.get("score", 0) or 0)
                band = str(o.get("band", "")).title()
                if band not in ("High", "Medium", "Low"):
                    band = "High" if score >= 70 else ("Medium" if score >= 45 else "Low")
                j["score"] = max(0, min(100, score))
                j["band"] = band
                j["why"] = str(o.get("why", ""))[:300]
                j["gaps"] = str(o.get("gaps", ""))[:250]
        except Exception as e:
            log(f"  ! Scoring batch {start // BATCH + 1} failed ({str(e)[:120]}); marking batch Unscored")
            for j in batch:
                j.setdefault("score", 0)
                j.setdefault("band", "Low")
                j.setdefault("why", "Not scored - LLM call failed for this batch")
                j.setdefault("gaps", "")
        done = min(start + BATCH, len(jobs))
        log(f"  Scored {done}/{len(jobs)} jobs")
        if prog is not None:
            prog.set(base + span * done / max(1, len(jobs)), f"Scoring jobs ({done}/{len(jobs)})")
    return jobs


# --------------------------------------------------------------- letters ---

def write_letters(provider, api_key, model, profile, jobs, n, log, prog=None, base=82, span=12):
    targets = [j for j in sorted(jobs, key=lambda x: -x.get("score", 0)) if j.get("band") == "High"][:n]
    if len(targets) < n:
        extra = [j for j in sorted(jobs, key=lambda x: -x.get("score", 0)) if j.get("band") == "Medium"]
        targets += extra[: n - len(targets)]
    if _use_demo(provider):
        demo = DemoLLM(profile.get("summary", ""))
        for j in targets:
            j["letter"] = demo.letter(j, profile)
        log(f"  Drafted letters for {len(targets)} jobs (demo templates)")
        return jobs

    for k, j in enumerate(targets, 1):
        user = f"""Candidate profile: {json.dumps({k2: profile.get(k2) for k2 in ('summary', 'strengths')}, ensure_ascii=False)}

Job: {j['title']} at {j['company']} ({j['location']}). Description snippet:
{j['description'][:1200]}

Write application materials in British English, first person, specific and unexaggerated.
Mirror 3-4 keywords from the job description. No placeholders except [Your name].
Return JSON: {{"email_subject": "...", "email_body": "120-160 words, ready to send",
"cover_letter": "230-300 words, 4 paragraphs"}}"""
        try:
            j["letter"] = extract_json(chat(provider, api_key, model, SYSTEM, user,
                                            max_tokens=1200, json_mode=True))
        except Exception as e:
            j["letter"] = {"email_subject": "", "email_body": f"(generation failed: {str(e)[:100]})",
                           "cover_letter": ""}
        log(f"  Letters {k}/{len(targets)} drafted")
        if prog is not None:
            prog.set(base + span * k / max(1, len(targets)), f"Drafting letters ({k}/{len(targets)})")
    return jobs


# ---------------------------------------------------------------- advice ---

def cv_advice(provider, api_key, model, profile, jobs, log):
    if _use_demo(provider):
        return ["Demo mode: connect a real LLM (Gemini free tier works) for tailored CV advice.",
                "Ensure every High-band job's top 3 keywords appear in your CV headline or first bullet.",
                "Quantify outcomes (ROI, adoption %, budget) on your two most recent roles."]
    gap_lines = [f"- {j['title']} @ {j['company']}: {j.get('gaps', '')}"
                 for j in jobs if j.get("band") in ("High", "Medium") and j.get("gaps") and j.get("gaps") != "None"][:25]
    user = f"""Candidate profile: {json.dumps({k: profile.get(k) for k in ('summary', 'strengths')}, ensure_ascii=False)}

Recruiter-observed gaps across this week's best-matched UK jobs:
{chr(10).join(gap_lines) or '(none captured)'}

Return JSON: {{"advice": ["8-10 specific, actionable CV improvements, ordered by impact,
each <=25 words, referencing concrete sections/keywords to change"]}}"""
    try:
        data = extract_json(chat(provider, api_key, model, SYSTEM, user, max_tokens=1200, json_mode=True))
        advice = [str(a) for a in data.get("advice", [])][:12]
        log(f"  CV advice generated ({len(advice)} points)")
        return advice
    except Exception as e:
        log(f"  ! CV advice failed ({str(e)[:100]})")
        return []
