"""Write the results workbook (openpyxl). Sheets: Dashboard, Jobs, Cover Letters, CV Improvements, Read Me."""
import datetime as dt

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ARIAL = "Arial"
DARK = "1F4E5F"
BAND_FILL = {"High": "C9EFD3", "Medium": "FFE9B3", "Low": "E9E9E9"}
THIN = Border(bottom=Side(style="thin", color="D9D9D9"))


def _head(ws, headers, widths, row=1):
    for c, (h, w) in enumerate(zip(headers, widths), 1):
        cell = ws.cell(row=row, column=c, value=h)
        cell.font = Font(name=ARIAL, bold=True, color="FFFFFF", size=10)
        cell.fill = PatternFill("solid", fgColor=DARK)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(c)].width = w
    ws.freeze_panes = ws.cell(row=row + 1, column=1).coordinate


def _cell(ws, r, c, v, wrap=True, bold=False, size=10, fill=None, link=None):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = Font(name=ARIAL, size=size, bold=bold,
                     color="0563C1" if link else "000000", underline="single" if link else None)
    cell.alignment = Alignment(vertical="top", wrap_text=wrap)
    cell.border = THIN
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if link:
        cell.hyperlink = link
    return cell


def build_workbook(out_path, profile, jobs, advice, meta):
    wb = Workbook()

    # ---------------- Dashboard ----------------
    ws = wb.active
    ws.title = "Dashboard"
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 80
    _cell(ws, 1, 1, "JobScout UK - run summary", bold=True, size=16)
    rows = [
        ("Run date", meta.get("run_date", "")),
        ("LLM used", meta.get("llm", "")),
        ("Sources searched", meta.get("sources", "")),
        ("Search titles", ", ".join(profile.get("target_titles", []))),
        ("Location / window", f"{meta.get('location', '')} / last {meta.get('days_back', '')} days"),
        ("Jobs found (after de-dup)", str(len(jobs))),
        ("High probability", '=COUNTIF(Jobs!A:A,"High")'),
        ("Medium probability", '=COUNTIF(Jobs!A:A,"Medium")'),
        ("Low probability", '=COUNTIF(Jobs!A:A,"Low")'),
        ("Sponsorship required (from CV)", "Yes" if profile.get("sponsorship_required") else "No"),
    ]
    for i, (k, v) in enumerate(rows, start=3):
        _cell(ws, i, 1, k, bold=True)
        _cell(ws, i, 2, v)
    _cell(ws, len(rows) + 4, 1,
          "Start with the Jobs sheet sorted by Band then Score. Letters for the top matches are in "
          "'Cover Letters'. Read 'Read Me' for honest limitations.", size=9)

    # ---------------- Jobs ----------------
    wsj = wb.create_sheet("Jobs")
    headers = ["Band", "Score", "Job title (click to open)", "Company", "Source", "Location",
               "Salary (advertised)", "Posted", "Sponsor register", "Why it fits", "CV gaps for this job", "Link"]
    widths = [9, 7, 40, 24, 10, 18, 17, 11, 22, 38, 30, 40]
    _head(wsj, headers, widths)
    order = {"High": 0, "Medium": 1, "Low": 2}
    sorted_jobs = sorted(jobs, key=lambda j: (order.get(j.get("band", "Low"), 3), -j.get("score", 0)))
    for r, j in enumerate(sorted_jobs, start=2):
        fill = BAND_FILL.get(j.get("band"))
        _cell(wsj, r, 1, j.get("band", ""), fill=fill, bold=True, wrap=False)
        _cell(wsj, r, 2, j.get("score", 0), wrap=False)
        _cell(wsj, r, 3, j.get("title", ""), link=j.get("url") or None)
        _cell(wsj, r, 4, j.get("company", ""))
        _cell(wsj, r, 5, j.get("source", ""), wrap=False)
        _cell(wsj, r, 6, j.get("location", ""))
        _cell(wsj, r, 7, j.get("salary", ""))
        _cell(wsj, r, 8, j.get("posted", ""), wrap=False)
        _cell(wsj, r, 9, j.get("sponsor", "Unknown"))
        _cell(wsj, r, 10, j.get("why", ""))
        _cell(wsj, r, 11, j.get("gaps", ""))
        _cell(wsj, r, 12, j.get("url", ""))
    wsj.auto_filter.ref = f"A1:L{max(2, len(sorted_jobs) + 1)}"

    # ---------------- Cover Letters ----------------
    wsl = wb.create_sheet("Cover Letters")
    _head(wsl, ["Band", "Job title", "Company", "Email subject", "Email body (ready to send)",
                "Cover letter (attach/paste)", "Link"], [9, 26, 20, 30, 55, 65, 30])
    r = 2
    for j in sorted_jobs:
        letter = j.get("letter")
        if not letter:
            continue
        _cell(wsl, r, 1, j.get("band", ""), fill=BAND_FILL.get(j.get("band")), bold=True, wrap=False)
        _cell(wsl, r, 2, j.get("title", ""))
        _cell(wsl, r, 3, j.get("company", ""))
        _cell(wsl, r, 4, letter.get("email_subject", ""))
        _cell(wsl, r, 5, letter.get("email_body", ""))
        _cell(wsl, r, 6, letter.get("cover_letter", ""))
        _cell(wsl, r, 7, j.get("url", ""), link=j.get("url") or None)
        wsl.row_dimensions[r].height = 150
        r += 1
    if r == 2:
        _cell(wsl, 2, 2, "No letters generated on this run.")

    # ---------------- CV Improvements ----------------
    wsa = wb.create_sheet("CV Improvements")
    _head(wsa, ["#", "Improvement (ordered by impact)"], [6, 110])
    for i, a in enumerate(advice or ["(none generated)"], start=1):
        _cell(wsa, i + 1, 1, i, wrap=False)
        _cell(wsa, i + 1, 2, a)

    # ---------------- Read Me ----------------
    wsr = wb.create_sheet("Read Me")
    wsr.column_dimensions["A"].width = 120
    notes = [
        "How to read this file",
        "- Band = the LLM's judgement of interview probability for YOUR CV: High (apply this week), "
        "Medium (apply with tailored CV), Low (weak use of time).",
        "- Scores are model judgements to prioritise effort - they are not guarantees.",
        "- Sponsor register: matched by company name against the official GOV.UK register of licensed "
        "sponsors. 'Not found' does NOT prove no licence (name variants are common) - always verify: "
        "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers",
        "- LinkedIn rows come from public listings and can be incomplete on some runs (rate limits).",
        "- Cover letters are DRAFTS. Personalise the first line for every application - recruiters "
        "discard obviously mass-generated letters.",
        "- Advertised salaries are often missing or wide; below GBP 41,700 cannot be sponsored, and "
        "BA/PM roles generally need ~GBP 55,000+ to clear the Skilled Worker going rate (2026 rules).",
        "- This tool never auto-submits applications.",
    ]
    _cell(wsr, 1, 1, notes[0], bold=True, size=13)
    for i, n in enumerate(notes[1:], start=3):
        _cell(wsr, i, 1, n, size=10)

    wb.save(out_path)
    return out_path


def default_filename():
    return f"JobScout_{dt.date.today().isoformat()}.xlsx"


def build_sponsor_workbook(out_path, profile, companies, meta, advice=None):
    """Second deliverable: licensed sponsor companies matched to the CV's sectors."""
    wb = Workbook()

    ws = wb.active
    ws.title = "Summary"
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 90
    _cell(ws, 1, 1, "JobScout UK - sponsor companies scan", bold=True, size=16)
    rows = [
        ("Run date", meta.get("run_date", "")),
        ("LLM used", meta.get("llm", "")),
        ("Sector keywords used", meta.get("keywords", "")),
        ("Companies in this file", str(len(companies))),
        ("Strong fit", '=COUNTIF(Companies!A:A,"High")'),
        ("Possible fit", '=COUNTIF(Companies!A:A,"Medium")'),
        ("Weak fit", '=COUNTIF(Companies!A:A,"Low")'),
        ("Advertising right now", '=COUNTIF(Companies!G:G,"YES*")'),
    ]
    for i, (k, v) in enumerate(rows, start=3):
        _cell(ws, i, 1, k, bold=True)
        _cell(ws, i, 2, v)
    _cell(ws, len(rows) + 4, 1,
          "Every company here holds a licence on the official GOV.UK register. 'None found today' "
          "does NOT mean don't apply - speculative applications to strong-fit sponsors are one of "
          "the highest-yield moves for sponsored candidates.", size=9)

    wsc = wb.create_sheet("Companies")
    headers = ["Fit", "Score", "Company", "Town", "Licence route(s)", "Type & rating",
               "Live jobs now", "Sample live advert", "Website", "Contact email(s)",
               "Why it matches your CV", "Careers page (search link)", "Company on LinkedIn"]
    widths = [9, 7, 30, 14, 21, 17, 22, 26, 26, 30, 36, 30, 30]
    _head(wsc, headers, widths)
    order = {"High": 0, "Medium": 1, "Low": 2}
    rows_sorted = sorted(companies, key=lambda o: (order.get(o.get("band", "Low"), 3), -o.get("score", 0)))
    for r, o in enumerate(rows_sorted, start=2):
        fill = BAND_FILL.get(o.get("band"))
        _cell(wsc, r, 1, o.get("band", ""), fill=fill, bold=True, wrap=False)
        _cell(wsc, r, 2, o.get("score", 0), wrap=False)
        _cell(wsc, r, 3, o.get("name", ""), bold=(o.get("band") == "High"))
        _cell(wsc, r, 4, o.get("town", ""))
        _cell(wsc, r, 5, o.get("routes_txt", ""))
        _cell(wsc, r, 6, o.get("ratings_txt", ""))
        _cell(wsc, r, 7, o.get("live", ""))
        _cell(wsc, r, 8, o.get("live_title", ""), link=o.get("live_link") or None)
        _cell(wsc, r, 9, o.get("website", "") or "-", link=o.get("website") or None)
        _cell(wsc, r, 10, o.get("emails", ""))
        _cell(wsc, r, 11, o.get("why", ""))
        _cell(wsc, r, 12, "Search careers page", link=o.get("careers_link") or None)
        _cell(wsc, r, 13, "Open LinkedIn search", link=o.get("linkedin_link") or None)
    wsc.auto_filter.ref = f"A1:M{max(2, len(rows_sorted) + 1)}"

    wso = wb.create_sheet("Outreach drafts")
    _head(wso, ["Fit", "Company", "Send to", "Subject", "Message (personalise the first line!)"],
          [9, 26, 30, 34, 70])
    r = 2
    for o in rows_sorted:
        d = o.get("outreach")
        if not d:
            continue
        _cell(wso, r, 1, o.get("band", ""), fill=BAND_FILL.get(o.get("band")), bold=True, wrap=False)
        _cell(wso, r, 2, o.get("name", ""))
        _cell(wso, r, 3, o.get("emails", ""))
        _cell(wso, r, 4, d.get("subject", ""))
        _cell(wso, r, 5, d.get("message", ""))
        wso.row_dimensions[r].height = 150
        r += 1
    if r == 2:
        _cell(wso, 2, 2, "No drafts generated on this run.")

    wsa = wb.create_sheet("CV Improvements")
    _head(wsa, ["#", "Change to make (ordered by impact, for sponsor-market applications)"], [6, 110])
    for i, a in enumerate(advice or ["(none generated)"], start=1):
        _cell(wsa, i + 1, 1, i, wrap=False)
        _cell(wsa, i + 1, 2, a)

    wsr = wb.create_sheet("Read Me")
    wsr.column_dimensions["A"].width = 120
    notes = [
        "How to use this file",
        "- Fit = LLM judgement of how well the company's likely business maps to YOUR CV. Start with "
        "High fit + 'YES - live adverts'.",
        "- 'Licence route(s)' comes from the official GOV.UK register (e.g. 'Skilled Worker' means the "
        "company can sponsor Skilled Worker visas; A rating = full licence in good standing).",
        "- 'Live jobs now' is checked against the Adzuna index at run time. 'None found today' still "
        "means the company CAN sponsor - send a speculative application with a tailored cover letter.",
        "- 'Careers page' is a one-click search shortcut (company sites move too often for stored URLs "
        "to stay reliable).",
        "- Honest limitation: the register has no sector column, so companies are discovered by words "
        "in their NAME. A retrofit firm called 'ABC Ltd' will not appear. Add your own keywords in the "
        "app to widen the net.",
        "- Websites are verified guesses (domain tried and page checked for the company name) - a blank "
        "means unconfirmed, use the search links. Emails are harvested from the company's own public "
        "pages; verify before sending, address a person where possible, and never mass-mail - one "
        "tailored message per company is what works.",
        "- Always verify the licence entry yourself before relying on it: "
        "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers",
    ]
    _cell(wsr, 1, 1, notes[0], bold=True, size=13)
    for i, n in enumerate(notes[1:], start=3):
        _cell(wsr, i, 1, n, size=10)

    wb.save(out_path)
    return out_path
