"""Job sources: Indeed + LinkedIn (via python-jobspy public listings), Adzuna API, Reed API.

Every source is best-effort: a failing source logs a warning and the run continues.
"""
import datetime as dt
import json
import os
import re
import sys

import requests

MAX_DESC = 1600


def _clean(s):
    if s is None:
        return ""
    if isinstance(s, float) and s != s:  # NaN from pandas
        return ""
    s = re.sub(r"<[^>]+>", " ", str(s))
    return re.sub(r"\s+", " ", s).strip()


def _nz(v):
    """None/NaN-safe string."""
    if v is None or (isinstance(v, float) and v != v):
        return ""
    return str(v)


def _salary_txt(mn, mx, unit="year"):
    def fmt(v):
        try:
            v = float(v)
        except (TypeError, ValueError):
            return None
        return f"{int(round(v)):,}"
    a, b = fmt(mn), fmt(mx)
    if not a and not b:
        return ""
    core = a if not b or a == b else f"{a}-{b}"
    unit_txt = {"year": "/yr", "hour": "/hr", "day": "/day", "month": "/mo"}.get(str(unit or "year").lower(), "")
    return f"GBP {core}{unit_txt}"


def make_job(source, title, company, location, salary, posted, url, description):
    return {
        "source": source,
        "title": _clean(title)[:160] or "(untitled)",
        "company": _clean(company)[:120] or "(unknown)",
        "location": _clean(location)[:100],
        "salary": _clean(salary)[:60],
        "posted": _clean(posted)[:20],
        "url": (url or "").strip(),
        "description": _clean(description)[:MAX_DESC],
    }


# ---------------------------------------------------------------- JobSpy ---

def from_jobspy(terms, location, days_back, per_term, log, sites=("indeed", "linkedin")):
    """Indeed + LinkedIn public listings via python-jobspy."""
    jobs = []
    if not sites:
        return jobs
    try:
        from jobspy import scrape_jobs
    except Exception as e:
        log(f"  ! python-jobspy not available ({e}); skipping Indeed/LinkedIn")
        return jobs

    for term in terms:
        for site in sites:
            try:
                df = scrape_jobs(
                    site_name=[site],
                    search_term=term,
                    location=location,
                    results_wanted=per_term,
                    hours_old=days_back * 24,
                    country_indeed="UK",
                    description_format="markdown",
                    verbose=0,
                )
                n = 0
                for _, r in df.iterrows():
                    jobs.append(make_job(
                        source={"indeed": "Indeed", "linkedin": "LinkedIn"}[site],
                        title=r.get("title"), company=r.get("company"),
                        location=r.get("location") or location,
                        salary=_salary_txt(r.get("min_amount"), r.get("max_amount"), _nz(r.get("interval")) or "year"),
                        posted=_nz(r.get("date_posted"))[:10],
                        url=r.get("job_url"), description=r.get("description"),
                    ))
                    n += 1
                log(f"  {site}: '{term}' -> {n} jobs")
            except Exception as e:
                log(f"  ! {site} '{term}' failed ({type(e).__name__}: {str(e)[:120]}) - continuing")
    return jobs


# ---------------------------------------------------------------- Adzuna ---

def from_adzuna(app_id, app_key, terms, location, days_back, per_term, log):
    jobs = []
    if not app_id or not app_key or "PASTE" in (app_id + app_key).upper():
        log("  Adzuna keys not set - skipping (free keys: developer.adzuna.com)")
        return jobs
    for term in terms:
        try:
            r = requests.get(
                "https://api.adzuna.com/v1/api/jobs/gb/search/1",
                params={
                    "app_id": app_id, "app_key": app_key,
                    "what": term, "where": location,
                    "max_days_old": days_back, "sort_by": "date",
                    "results_per_page": min(per_term, 50),
                    "content-type": "application/json",
                },
                timeout=45,
            )
            if r.status_code != 200:
                log(f"  ! Adzuna '{term}' HTTP {r.status_code}: {r.text[:100]}")
                continue
            results = r.json().get("results", [])
            for j in results:
                jobs.append(make_job(
                    source="Adzuna",
                    title=j.get("title"), company=(j.get("company") or {}).get("display_name"),
                    location=(j.get("location") or {}).get("display_name") or location,
                    salary=_salary_txt(j.get("salary_min"), j.get("salary_max")),
                    posted=str(j.get("created", ""))[:10],
                    url=j.get("redirect_url"), description=j.get("description"),
                ))
            log(f"  Adzuna: '{term}' -> {len(results)} jobs")
        except Exception as e:
            log(f"  ! Adzuna '{term}' failed ({type(e).__name__}) - continuing")
    return jobs


# ------------------------------------------------------------------ Reed ---

def from_reed(api_key, terms, location, distance_miles, days_back, per_term, log):
    jobs = []
    if not api_key or "PASTE" in api_key.upper():
        log("  Reed key not set - skipping (free key: reed.co.uk/developers/jobseeker)")
        return jobs
    cutoff = dt.date.today() - dt.timedelta(days=days_back)
    for term in terms:
        try:
            r = requests.get(
                "https://www.reed.co.uk/api/1.0/search",
                auth=(api_key, ""),
                params={
                    "keywords": term, "locationName": location,
                    "distanceFromLocation": distance_miles,
                    "resultsToTake": min(per_term, 100),
                },
                timeout=45,
            )
            if r.status_code != 200:
                log(f"  ! Reed '{term}' HTTP {r.status_code}: {r.text[:100]}")
                continue
            kept = 0
            for j in r.json().get("results", []):
                posted = str(j.get("date", ""))  # DD/MM/YYYY
                try:
                    pdate = dt.datetime.strptime(posted, "%d/%m/%Y").date()
                    if pdate < cutoff:
                        continue
                    posted_iso = pdate.isoformat()
                except ValueError:
                    posted_iso = posted
                jobs.append(make_job(
                    source="Reed",
                    title=j.get("jobTitle"), company=j.get("employerName"),
                    location=j.get("locationName") or location,
                    salary=_salary_txt(j.get("minimumSalary"), j.get("maximumSalary")),
                    posted=posted_iso, url=j.get("jobUrl"),
                    description=j.get("jobDescription"),
                ))
                kept += 1
            log(f"  Reed: '{term}' -> {kept} jobs (last {days_back} days)")
        except Exception as e:
            log(f"  ! Reed '{term}' failed ({type(e).__name__}) - continuing")
    return jobs


# ------------------------------------------------------------- utilities ---

def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def dedupe(jobs, log):
    seen, out = {}, []
    for j in jobs:
        key = (_norm(j["title"]), _norm(j["company"]))
        if key in seen:
            continue
        seen[key] = True
        out.append(j)
    log(f"  De-duplicated: {len(jobs)} -> {len(out)} unique jobs")
    return out


def test_reed(api_key):
    """(ok, message) - one tiny live query to validate the key."""
    if not api_key or "PASTE" in api_key.upper():
        return False, "No Reed key entered"
    try:
        r = requests.get("https://www.reed.co.uk/api/1.0/search",
                         auth=(api_key, ""), params={"keywords": "analyst", "resultsToTake": 1}, timeout=30)
        if r.status_code == 200:
            return True, "Reed API connected"
        return False, f"Reed HTTP {r.status_code} - check the key"
    except Exception as e:
        return False, f"Reed: {type(e).__name__}"


def test_adzuna(app_id, app_key):
    if not app_id or not app_key or "PASTE" in (app_id + app_key).upper():
        return False, "No Adzuna ID/key entered"
    try:
        r = requests.get("https://api.adzuna.com/v1/api/jobs/gb/search/1",
                         params={"app_id": app_id, "app_key": app_key, "what": "analyst",
                                 "results_per_page": 1}, timeout=30)
        if r.status_code == 200:
            return True, "Adzuna API connected"
        return False, f"Adzuna HTTP {r.status_code} - check ID/key"
    except Exception as e:
        return False, f"Adzuna: {type(e).__name__}"


def load_sample_jobs():
    """Bundled offline sample for Demo mode (works from source AND from the packaged .exe)."""
    candidates = []
    meipass = getattr(sys, "_MEIPASS", None)  # PyInstaller onefile extraction dir
    if meipass:
        candidates.append(os.path.join(meipass, "sample_jobs.json"))
    if getattr(sys, "frozen", False):
        candidates.append(os.path.join(os.path.dirname(sys.executable), "sample_jobs.json"))
    candidates.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sample_jobs.json"))
    for path in candidates:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    raise FileNotFoundError("sample_jobs.json not found")
