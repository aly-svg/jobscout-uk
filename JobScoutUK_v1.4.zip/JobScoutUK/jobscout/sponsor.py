"""The official UK register of licensed sponsors (Workers) - download, cache, match, browse.

Used two ways:
  1. Job scan  - check(): is this employer's name on the register?
  2. Sponsor scan - orgs list: browse companies by sector keyword, with licence route/rating.

Matching is by normalised company name. 'Not found' does NOT prove an employer has no
licence (name variants are common); it is a prioritisation signal only.
"""
import csv
import difflib
import os
import re
import time

import requests

PUB_URL = "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers"
CACHE_DAYS = 7
SUFFIXES = {"ltd", "limited", "plc", "llp", "llc", "uk", "gb", "group", "holdings",
            "holding", "international", "services", "service", "solutions", "company",
            "co", "the", "and", "of"}


def normalise(name):
    words = re.sub(r"[^a-z0-9 ]+", " ", (name or "").lower()).split()
    core = [w for w in words if w not in SUFFIXES]
    return " ".join(core or words)


class SponsorRegister:
    def __init__(self, names, orgs):
        self.names = names                       # set of normalised names
        self.orgs = orgs                         # list of {name, town, routes, ratings}
        self.by_first = {}
        for n in names:
            if n:
                self.by_first.setdefault(n[0], []).append(n)

    def check(self, company):
        n = normalise(company)
        if not n:
            return "Unknown"
        if n in self.names:
            return "Yes - on register"
        if len(n) >= 6:
            bucket = self.by_first.get(n[0], [])
            for cand in bucket:
                if len(cand) >= 6 and (n in cand or cand in n):
                    return "Probable - name variant on register"
            close = difflib.get_close_matches(n, bucket, n=1, cutoff=0.93)
            if close:
                return "Probable - name variant on register"
        return "Not found - verify before applying"


def _pick(header, *needles):
    """Find a column index whose header contains all needle words (case-insensitive)."""
    low = [h.strip().lower() for h in header]
    for i, h in enumerate(low):
        if all(nd in h for nd in needles):
            return i
    return None


def load_register(cache_dir, log):
    """Return a SponsorRegister, or None if unavailable (job scan continues without it)."""
    os.makedirs(cache_dir, exist_ok=True)
    cache_csv = os.path.join(cache_dir, "sponsor_register.csv")
    try:
        fresh = (os.path.exists(cache_csv)
                 and (time.time() - os.path.getmtime(cache_csv)) < CACHE_DAYS * 86400)
        if not fresh:
            if os.environ.get("JOBSCOUT_OFFLINE"):
                raise RuntimeError("offline mode - no cached register")
            log("  Downloading official sponsor register from GOV.UK (weekly cache)...")
            page = requests.get(PUB_URL, timeout=60, headers={"User-Agent": "Mozilla/5.0 JobScoutUK"})
            page.raise_for_status()
            m = re.search(r'https://assets\.publishing\.service\.gov\.uk/[^"\' ]+?\.csv', page.text)
            if not m:
                raise RuntimeError("CSV link not found on GOV.UK page")
            data = requests.get(m.group(0), timeout=300, headers={"User-Agent": "Mozilla/5.0 JobScoutUK"})
            data.raise_for_status()
            with open(cache_csv, "wb") as f:
                f.write(data.content)

        names = set()
        agg = {}   # normalised name -> org dict
        with open(cache_csv, "r", encoding="utf-8-sig", errors="replace") as f:
            reader = csv.reader(f)
            header = next(reader, [])
            i_name = _pick(header, "organisation") or 0
            i_town = _pick(header, "town")
            i_type = _pick(header, "type")     # "Type & Rating"
            i_route = _pick(header, "route")
            for row in reader:
                if not row or len(row) <= i_name or not row[i_name].strip():
                    continue
                disp = row[i_name].strip()
                n = normalise(disp)
                names.add(n)
                o = agg.get(n)
                if o is None:
                    o = {"name": disp, "town": "", "routes": set(), "ratings": set()}
                    agg[n] = o
                if i_town is not None and len(row) > i_town and row[i_town].strip() and not o["town"]:
                    o["town"] = row[i_town].strip()
                if i_route is not None and len(row) > i_route and row[i_route].strip():
                    o["routes"].add(row[i_route].strip())
                if i_type is not None and len(row) > i_type and row[i_type].strip():
                    o["ratings"].add(row[i_type].strip())
        orgs = list(agg.values())
        log(f"  Sponsor register loaded: {len(orgs):,} organisations")
        return SponsorRegister(names, orgs)
    except Exception as e:
        log(f"  ! Sponsor register unavailable ({type(e).__name__}: {str(e)[:100]})")
        return None
