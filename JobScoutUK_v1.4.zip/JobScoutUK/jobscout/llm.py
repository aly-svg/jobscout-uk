"""Provider-agnostic LLM client: Gemini, OpenAI, Claude — plus an offline Demo engine.

Uses plain REST calls (requests) so there are no vendor SDK dependencies.
"""
import json
import re
import time

import requests

DEFAULT_MODELS = {
    "Gemini": "gemini-2.5-flash",
    "OpenAI": "gpt-4o-mini",
    "Claude": "claude-haiku-4-5",
}

TIMEOUT = 180


class LLMError(Exception):
    pass


def chat(provider, api_key, model, system, user, max_tokens=4000, temperature=0.3, json_mode=False):
    """Send one chat request, return the text reply. Retries once on 429/5xx."""
    provider = (provider or "").strip()
    if provider == "Demo (offline)":
        raise LLMError("Demo mode does not use the network LLM client.")
    if not api_key or "PASTE" in api_key.upper():
        raise LLMError(f"No API key set for {provider}. Paste your key in the app and try again.")
    model = (model or DEFAULT_MODELS.get(provider, "")).strip()

    last_err = None
    for attempt in (1, 2):
        try:
            if provider == "OpenAI":
                return _openai(api_key, model, system, user, max_tokens, temperature, json_mode)
            if provider == "Gemini":
                return _gemini(api_key, model, system, user, max_tokens, temperature, json_mode)
            if provider == "Claude":
                return _claude(api_key, model, system, user, max_tokens, temperature)
            raise LLMError(f"Unknown provider: {provider}")
        except LLMError as e:
            last_err = e
            msg = str(e)
            retriable = any(code in msg for code in ("429", "500", "502", "503", "529"))
            if attempt == 1 and retriable:
                time.sleep(12)
                continue
            raise
    raise last_err


def _openai(key, model, system, user, max_tokens, temperature, json_mode):
    body = {
        "model": model,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    r = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json=body, timeout=TIMEOUT,
    )
    if r.status_code != 200:
        raise LLMError(f"OpenAI error {r.status_code}: {r.text[:300]}")
    return r.json()["choices"][0]["message"]["content"]


def _gemini(key, model, system, user, max_tokens, temperature, json_mode):
    gen = {"temperature": temperature, "maxOutputTokens": max_tokens}
    if json_mode:
        gen["responseMimeType"] = "application/json"
    body = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [{"role": "user", "parts": [{"text": user}]}],
        "generationConfig": gen,
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    r = requests.post(url, json=body, timeout=TIMEOUT)
    if r.status_code != 200:
        raise LLMError(f"Gemini error {r.status_code}: {r.text[:300]}")
    data = r.json()
    try:
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError):
        raise LLMError(f"Gemini returned no text: {json.dumps(data)[:300]}")


def _claude(key, model, system, user, max_tokens, temperature):
    body = {
        "model": model,
        "system": system,
        "messages": [{"role": "user", "content": user}],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    r = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
        json=body, timeout=TIMEOUT,
    )
    if r.status_code != 200:
        raise LLMError(f"Claude error {r.status_code}: {r.text[:300]}")
    parts = r.json().get("content", [])
    return "".join(p.get("text", "") for p in parts if p.get("type") == "text")


def extract_json(text):
    """Parse JSON out of an LLM reply that may include code fences or prose."""
    if text is None:
        raise LLMError("Empty LLM reply.")
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass
    for pattern in (r"\[.*\]", r"\{.*\}"):
        m = re.search(pattern, t, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                continue
    raise LLMError(f"Could not parse JSON from LLM reply: {t[:200]}")


# ----------------------------------------------------------------------
# Offline demo engine: deterministic, no network, used by "Demo (offline)"
# provider so the app can be tested before any API keys exist.
# ----------------------------------------------------------------------

STOP = set("""a an and are as at be by for from has have in is it its of on or that the this to was were will with
your you our their they i we he she not no yes over under years year month months experience work working""".split())


def _keywords(text, top=80):
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9+/#.-]{2,}", (text or "").lower())
    freq = {}
    for w in words:
        if w in STOP:
            continue
        freq[w] = freq.get(w, 0) + 1
    return dict(sorted(freq.items(), key=lambda kv: -kv[1])[:top])


class DemoLLM:
    """Rule-based stand-in for a real model. Keyword overlap scoring."""

    def __init__(self, cv_text):
        self.cv_text = cv_text or ""
        self.cv_kw = _keywords(self.cv_text, top=150)

    def profile(self):
        titles = []
        for t in ("Business Analyst", "IT Project Manager", "SAP Business Analyst",
                  "ERP Project Manager", "Delivery Manager"):
            if any(w in self.cv_text.lower() for w in t.lower().split()):
                titles.append(t)
        return {
            "summary": self.cv_text[:400].replace("\n", " "),
            "target_titles": titles[:5] or ["Business Analyst", "Project Manager"],
            "strengths": list(self.cv_kw.keys())[:10],
            "sponsorship_required": "sponsorship" in self.cv_text.lower(),
            "minimum_salary": 55000,
        }

    def score(self, job):
        jk = _keywords((job.get("title", "") + " " + job.get("description", "")), top=80)
        overlap = sum(1 for w in jk if w in self.cv_kw)
        score = max(15, min(95, int(overlap * 4)))
        band = "High" if score >= 70 else ("Medium" if score >= 45 else "Low")
        shared = [w for w in jk if w in self.cv_kw][:6]
        return {
            "score": score, "band": band,
            "why": "Keyword overlap (demo scoring): " + ", ".join(shared),
            "gaps": "Demo mode - connect a real LLM for genuine gap analysis.",
        }

    def letter(self, job, profile):
        t, c = job.get("title", "the role"), job.get("company", "your company")
        skills = ", ".join(list(self.cv_kw.keys())[:4]) or "my core skills"
        return {
            "email_subject": f"Application: {t} at {c}",
            "email_body": (f"Dear Hiring Team,\n\nI am applying for the {t} position at {c}. "
                           f"My background aligns with this role, particularly around {skills}.\n\n"
                           "My CV is attached; I would welcome a conversation.\n\n"
                           "Kind regards,\n[Your name]\n\n"
                           "[DEMO DRAFT - connect a real LLM (free Gemini key) for a tailored, specific email]"),
            "cover_letter": (f"[DEMO DRAFT - connect a real LLM for a tailored letter]\n\n"
                             f"Re: {t} at {c}\n\nBased on keyword analysis, my experience with {skills} "
                             "matches this vacancy. A connected LLM will write a specific, evidence-based "
                             "letter from your actual CV here.\n"),
        }


def quick_test(provider, api_key, model):
    """One tiny live call to verify a key works. Returns (ok, message)."""
    if provider == "Demo (offline)":
        return True, "Demo mode needs no key"
    try:
        reply = chat(provider, api_key, model, "You are a connection test.",
                     "Reply with exactly: OK", max_tokens=1000, temperature=0)
        if reply and "OK" in reply.upper():
            return True, f"Connected - {model or DEFAULT_MODELS.get(provider, '')} responding"
        return True, f"Connected - unexpected reply: {str(reply)[:40]}"
    except LLMError as e:
        return False, str(e)[:200]
    except Exception as e:
        return False, f"{type(e).__name__}: {str(e)[:150]}"
