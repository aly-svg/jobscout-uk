"""Orchestrates a full run: CV -> profile -> search -> sponsor check -> score -> letters -> Excel."""
import datetime as dt
import os

from . import excel, resume, scoring, sources, sponsor


class NullProgress:
    def set(self, pct, stage=None):
        pass

    def log(self, msg):
        pass

    def summary(self, **kw):
        pass


def run(params, log, prog=None):
    """params keys: resume_path, provider, api_key, model, adzuna_app_id, adzuna_app_key,
    reed_api_key, location, distance_miles, days_back, max_jobs, letters_for_top,
    extra_titles (str, comma separated, optional), out_dir, demo (bool).

    log(msg) receives every progress line; prog (optional) receives .set(pct, stage)
    and a final .summary(high=..., medium=..., low=..., total=..., file=...).
    """
    prog = prog or NullProgress()
    out_dir = params.get("out_dir") or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
    os.makedirs(out_dir, exist_ok=True)
    demo = bool(params.get("demo"))
    provider = "Demo (offline)" if demo else params["provider"]

    prog.set(3, "Reading your CV")
    log("STEP 1/6 - Reading your CV...")
    cv_text = resume.read_resume(params["resume_path"])
    log(f"  CV read: {len(cv_text):,} characters")
    prog.set(6, "Understanding your profile")

    log("STEP 2/6 - Building your profile with the LLM...")
    profile = scoring.build_profile(provider, params.get("api_key", ""), params.get("model", ""), cv_text, log)
    extra = [t.strip() for t in (params.get("extra_titles") or "").split(",") if t.strip()]
    titles = list(dict.fromkeys(extra + profile.get("target_titles", [])))[:6]
    profile["target_titles"] = titles
    log(f"  Searching for: {', '.join(titles)}")
    prog.set(15, "Searching UK job sources")

    log("STEP 3/6 - Searching UK job sources...")
    if demo:
        jobs = sources.load_sample_jobs()
        log(f"  Demo mode: loaded {len(jobs)} bundled sample jobs (no internet used)")
        prog.set(45, "Searching UK job sources")
    else:
        location = params.get("location") or "London"
        days = int(params.get("days_back") or 7)
        per_term = max(10, int(params.get("max_jobs") or 60) // max(1, len(titles)))
        portals = [p.lower() for p in (params.get("portals") or ["reed", "adzuna", "indeed", "linkedin"])]
        log(f"  Portals selected: {', '.join(portals)}")
        jobs = []
        if "reed" in portals:
            jobs += sources.from_reed(params.get("reed_api_key", ""), titles, location,
                                      int(params.get("distance_miles") or 15), days, per_term, log)
        prog.set(25, "Searching Adzuna")
        if "adzuna" in portals:
            jobs += sources.from_adzuna(params.get("adzuna_app_id", ""), params.get("adzuna_app_key", ""),
                                        titles, location, days, per_term, log)
        prog.set(33, "Searching Indeed + LinkedIn (public listings)")
        spy_sites = tuple(s for s in ("indeed", "linkedin") if s in portals)
        jobs += sources.from_jobspy(titles, location + ", UK", days, min(per_term, 25), log, sites=spy_sites)
        prog.set(45, "De-duplicating")
    jobs = sources.dedupe(jobs, log)
    max_jobs = int(params.get("max_jobs") or 60)
    if len(jobs) > max_jobs:
        log(f"  Capping at the {max_jobs} most recent jobs (raise 'Max jobs' to keep more)")
        jobs = sorted(jobs, key=lambda j: j.get("posted", ""), reverse=True)[:max_jobs]
    if not jobs:
        raise RuntimeError("No jobs found. Check your API keys / internet, widen the search window, "
                           "or add search titles, then run again.")
    prog.set(48, "Checking the GOV.UK sponsor register")

    log("STEP 4/6 - Checking employers against the GOV.UK sponsor register...")
    if profile.get("sponsorship_required"):
        reg = None if demo else sponsor.load_register(os.path.join(out_dir, ".cache"), log)
        for j in jobs:
            j["sponsor"] = reg.check(j["company"]) if reg else "Unknown"
    else:
        for j in jobs:
            j["sponsor"] = "n/a (no sponsorship need stated in CV)"
        log("  CV does not state a sponsorship need - skipping register download")
    prog.set(55, "Scoring jobs against your CV")

    log("STEP 5/6 - Scoring every job against your CV (High / Medium / Low)...")
    jobs = scoring.score_jobs(provider, params.get("api_key", ""), params.get("model", ""),
                              profile, jobs, log, prog=prog, base=55, span=27)
    n_letters = int(params.get("letters_for_top") or 8)
    prog.set(82, "Drafting emails and cover letters")
    log(f"STEP 5b - Drafting email + cover letter for the top {n_letters} matches...")
    jobs = scoring.write_letters(provider, params.get("api_key", ""), params.get("model", ""),
                                 profile, jobs, n_letters, log, prog=prog, base=82, span=12)
    prog.set(95, "Writing CV improvement advice")
    advice = scoring.cv_advice(provider, params.get("api_key", ""), params.get("model", ""), profile, jobs, log)

    prog.set(97, "Writing the Excel workbook")
    log("STEP 6/6 - Writing the Excel workbook...")
    meta = {
        "run_date": dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "llm": f"{provider} ({params.get('model') or 'default'})" if not demo else "Demo (offline keyword engine)",
        "sources": "Demo sample data" if demo else "Reed API, Adzuna API, Indeed + LinkedIn (public listings)",
        "location": params.get("location", "London"),
        "days_back": params.get("days_back", 7),
    }
    out_path = os.path.join(out_dir, excel.default_filename())
    excel.build_workbook(out_path, profile, jobs, advice, meta)
    high = sum(1 for j in jobs if j.get("band") == "High")
    med = sum(1 for j in jobs if j.get("band") == "Medium")
    low = sum(1 for j in jobs if j.get("band") == "Low")
    prog.summary(high=high, medium=med, low=low, total=len(jobs), file=out_path)
    prog.set(100, "Done")
    log(f"DONE - {len(jobs)} jobs analysed: {high} High, {med} Medium, {low} Low. Excel saved to:")
    log(f"  {out_path}")
    return out_path
