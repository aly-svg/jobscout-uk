"""Sponsor-companies scan: find licensed sponsors in the sectors that match the CV,
whether or not they are advertising today, and write a second Excel.

Steps: CV profile -> sector name-keywords (LLM) -> filter the official register by
organisation NAME keywords -> LLM relevance scoring -> live-ads check via Adzuna ->
careers-page and LinkedIn search links -> workbook.

Honest limitation: the GOV.UK register lists only name/town/route - no sector column -
so sector discovery works by company-NAME keywords. A sponsor called e.g. 'ABC Ltd'
doing retrofit work will not be caught. The Excel says this on its Read Me sheet.
"""
import json
import os
import re
import time
import urllib.parse

import requests

from . import excel, resume, sponsor
from .llm import chat, extract_json, DemoLLM
from .scoring import SYSTEM, build_profile, _use_demo

DEMO_FALLBACK_KEYWORDS = [
    "energy", "retrofit", "solar", "renewable", "heating", "heat pump", "insulation",
    "property", "housing", "lettings", "estate", "construction", "utilities", "power",
    "consult", "technology", "digital", "software", "erp", "supply chain", "logistics",
]

BATCH = 12


def _keywords_from_llm(provider, api_key, model, profile, log):
    if _use_demo(provider):
        log("  Sector keywords (demo defaults): " + ", ".join(DEMO_FALLBACK_KEYWORDS[:8]) + "...")
        return DEMO_FALLBACK_KEYWORDS
    user = f"""Candidate profile: {json.dumps({k: profile.get(k) for k in ('summary', 'strengths')}, ensure_ascii=False)}

The official UK sponsor register lists ~100,000 company NAMES with no sector field.
Give 15-25 lowercase keywords likely to appear IN THE NAMES of companies in this
candidate's sectors (industry words, not job titles). Think: what words appear in
company names in their industries? e.g. "energy", "solar", "housing".
Return JSON: {{"keywords": ["...", "..."]}}"""
    try:
        data = extract_json(chat(provider, api_key, model, SYSTEM, user, max_tokens=800, json_mode=True))
        kws = [str(k).strip().lower() for k in data.get("keywords", []) if len(str(k).strip()) >= 4][:25]
        if len(kws) < 5:
            kws = DEMO_FALLBACK_KEYWORDS
        log("  Sector keywords: " + ", ".join(kws))
        return kws
    except Exception as e:
        log(f"  ! Keyword generation failed ({str(e)[:80]}); using sensible defaults")
        return DEMO_FALLBACK_KEYWORDS


def _load_orgs(demo, cache_dir, log):
    reg = sponsor.load_register(cache_dir, log)
    if reg and reg.orgs:
        return reg.orgs
    if demo:
        path_candidates = []
        import sys
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            path_candidates.append(os.path.join(meipass, "sample_sponsors.json"))
        path_candidates.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                            "sample_sponsors.json"))
        for p in path_candidates:
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    orgs = json.load(f)
                for o in orgs:
                    o["routes"] = set(o.get("routes", []))
                    o["ratings"] = set(o.get("ratings", []))
                log(f"  Demo fallback: {len(orgs)} bundled sample sponsor companies")
                return orgs
    raise RuntimeError("Could not load the sponsor register (internet needed the first time each week).")


def _filter_orgs(orgs, keywords, location, max_companies, log):
    kws = [k for k in keywords if len(k) >= 4]
    hits = []
    for o in orgs:
        name_l = " " + o["name"].lower() + " "
        matched = [k for k in kws if k in name_l]
        if matched:
            hits.append((o, matched))
    loc = (location or "").strip().lower()
    hits.sort(key=lambda h: (0 if loc and loc in (h[0].get("town", "") or "").lower() else 1,
                             h[0]["name"].lower()))
    log(f"  Name-keyword filter: {len(hits):,} sponsor companies matched"
        + (f"; keeping the first {max_companies} ({location} first)" if len(hits) > max_companies else ""))
    return hits[:max_companies]


def _score_companies(provider, api_key, model, profile, items, log, prog, base=45, span=25):
    """items: list of (org, matched_keywords). Adds score/band/why to org dicts."""
    if _use_demo(provider):
        for o, matched in items:
            score = min(88, 30 + 20 * len(matched))
            band = "High" if score >= 70 else ("Medium" if score >= 45 else "Low")
            o.update({"score": score, "band": band,
                      "why": "Name matches your sectors: " + ", ".join(matched)})
        log(f"  Relevance scored (demo keyword engine): {len(items)} companies")
        return

    for start in range(0, len(items), BATCH):
        batch = items[start:start + BATCH]
        lines = [json.dumps({"i": i, "company": o["name"], "town": o.get("town", ""),
                             "name_matched_on": m}, ensure_ascii=False)
                 for i, (o, m) in enumerate(batch)]
        user = f"""Candidate profile: {json.dumps({k: profile.get(k) for k in ('summary', 'strengths')}, ensure_ascii=False)}

These UK companies hold a sponsor licence. Judging ONLY from each company's name, town and
the keyword it matched, rate how promising a speculative application is for THIS candidate.
Return a JSON array: {{"i": <index>, "score": 0-100, "band": "High"|"Medium"|"Low",
"why": "<=18 words - the likely business and which CV experience maps to it"}}
Be discriminating: recruitment agencies, tiny shops and unrelated trades = Low.

Companies:
{chr(10).join(lines)}"""
        try:
            arr = extract_json(chat(provider, api_key, model, SYSTEM, user, max_tokens=2200, json_mode=True))
            if isinstance(arr, dict):
                arr = arr.get("results") or arr.get("companies") or []
            by_i = {int(x.get("i", -1)): x for x in arr if isinstance(x, dict)}
            for i, (o, m) in enumerate(batch):
                x = by_i.get(i, {})
                score = int(x.get("score", 0) or 0)
                band = str(x.get("band", "")).title()
                if band not in ("High", "Medium", "Low"):
                    band = "High" if score >= 70 else ("Medium" if score >= 45 else "Low")
                o.update({"score": max(0, min(100, score)), "band": band,
                          "why": str(x.get("why", ""))[:200]})
        except Exception as e:
            log(f"  ! Company scoring batch failed ({str(e)[:80]}); marking batch Medium")
            for o, m in batch:
                o.update({"score": 50, "band": "Medium", "why": "Name matched: " + ", ".join(m)})
        done = min(start + BATCH, len(items))
        log(f"  Relevance scored {done}/{len(items)} companies")
        prog.set(base + span * done / max(1, len(items)), f"Scoring companies ({done}/{len(items)})")


def _live_ads_indeed(companies, log, prog, base=70, span=8, top_n=12, time_budget=150):
    """Keyless fallback: check recent Indeed listings per company via public search."""
    try:
        from jobspy import scrape_jobs
    except Exception as e:
        log(f"  ! Live-jobs check unavailable ({str(e)[:80]})")
        for o in companies:
            o.setdefault("live", "Unknown - could not check")
        return
    targets = sorted(companies, key=lambda o: -o.get("score", 0))[:top_n]
    log(f"  Checking recent Indeed adverts for the top {len(targets)} companies (no key needed)...")
    t0 = time.time()
    for k, o in enumerate(targets, 1):
        if time.time() - t0 > time_budget:
            log("  Live-jobs time-box reached - remaining companies marked 'Not checked'")
            break
        try:
            df = scrape_jobs(site_name=["indeed"], search_term=f'company:"{o["name"]}"',
                             results_wanted=3, hours_old=30 * 24, country_indeed="UK", verbose=0)
            n = len(df)
            if n > 0:
                o["live"] = f"YES - {n}+ recent Indeed advert(s)"
                first = df.iloc[0]
                o["live_link"] = str(first.get("job_url") or "")
                o["live_title"] = str(first.get("title") or "")
            else:
                o["live"] = "None found this month - apply speculatively"
        except Exception:
            o["live"] = "Unknown - lookup failed"
        if k % 4 == 0 or k == len(targets):
            prog.set(base + span * k / max(1, len(targets)), f"Checking live jobs ({k}/{len(targets)})")
    for o in companies:
        o.setdefault("live", "Not checked (outside top matches)")


def _live_ads(app_id, app_key, companies, log, prog, base=70, span=22, top_n=30):
    """Check current live adverts per company via the Adzuna API 'company' filter."""
    have_keys = app_id and app_key and "PASTE" not in (app_id + app_key).upper()
    if not have_keys:
        _live_ads_indeed(companies, log, prog, base=base, span=span)
        return
    targets = sorted(companies, key=lambda o: -o.get("score", 0))[:top_n]
    for k, o in enumerate(targets, 1):
        try:
            r = requests.get("https://api.adzuna.com/v1/api/jobs/gb/search/1",
                             params={"app_id": app_id, "app_key": app_key,
                                     "company": o["name"], "results_per_page": 3},
                             timeout=30)
            if r.status_code != 200:
                o["live"] = "Unknown - Adzuna error"
                continue
            data = r.json()
            count = int(data.get("count", 0) or 0)
            if count > 0:
                o["live"] = f"YES - {count} live advert(s)"
                first = (data.get("results") or [{}])[0]
                o["live_link"] = first.get("redirect_url", "")
                o["live_title"] = (first.get("title") or "").replace("<strong>", "").replace("</strong>", "")
            else:
                o["live"] = "None found today - apply speculatively"
        except Exception:
            o["live"] = "Unknown - lookup failed"
        if k % 5 == 0 or k == len(targets):
            log(f"  Live-adverts check {k}/{len(targets)}")
            prog.set(base + span * k / max(1, len(targets)), f"Checking live jobs ({k}/{len(targets)})")
    for o in companies:
        o.setdefault("live", "Not checked (outside top matches)")


# ----------------------------------------------------- website + emails ---

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_BAD_EMAIL = ("example.", "sentry", "wixpress", ".png", ".jpg", ".gif", "@2x", "yourdomain",
              "email@", "name@", "domain.")
_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) JobScoutUK/1.3"}


def _domain_candidates(name):
    words = re.sub(r"[^a-z0-9 ]", "", name.lower()).split()
    drop = {"ltd", "limited", "plc", "llp", "uk", "the", "group", "and", "co", "company", "services"}
    core = [w for w in words if w not in drop][:3]
    if not core:
        return []
    joined = "".join(core)
    dashed = "-".join(core)
    slugs = [joined] if joined == dashed else [joined, dashed]
    urls = []
    for s in slugs:
        if 3 <= len(s) <= 40:
            urls += [f"https://www.{s}.co.uk", f"https://www.{s}.com"]
    return urls[:3]


def _fetch(url, timeout=6):
    r = requests.get(url, timeout=timeout, headers=_UA, allow_redirects=True)
    if r.status_code != 200 or "text/html" not in r.headers.get("Content-Type", "text/html"):
        return None, None
    return r.url, r.text[:200000]


def _emails_from(html):
    found = []
    for e in _EMAIL_RE.findall(html or ""):
        el = e.lower().strip(".")
        if any(b in el for b in _BAD_EMAIL) or el in found:
            continue
        found.append(el)
    pri = ("careers@", "jobs@", "recruitment@", "hr@", "talent@", "info@", "hello@",
           "enquiries@", "contact@", "office@", "admin@")
    found.sort(key=lambda e: next((i for i, p in enumerate(pri) if e.startswith(p)), 99))
    return found[:3]


def _enrich_contacts(companies, log, prog, base=70, span=20, top_n=25, time_budget=200):
    """Resolve real websites (verified guess) + harvest public contact emails for the top matches."""
    if os.environ.get("JOBSCOUT_OFFLINE"):
        log("  Offline mode - website/email lookup skipped")
        return
    targets = sorted(companies, key=lambda o: -o.get("score", 0))[:top_n]
    t0 = time.time()
    hits = 0
    for k, o in enumerate(targets, 1):
        if time.time() - t0 > time_budget:
            log(f"  Contact lookup time-box reached ({time_budget}s) - remaining companies keep search links")
            break
        name_tokens = [w for w in re.sub(r"[^a-z0-9 ]", "", o["name"].lower()).split() if len(w) > 3][:3]
        site = html = None
        for cand in _domain_candidates(o["name"]):
            try:
                url, page = _fetch(cand)
                if page and name_tokens and any(t in page.lower() for t in name_tokens):
                    site, html = url, page
                    break
            except Exception:
                continue
        if site:
            o["website"] = site
            emails = _emails_from(html)
            # try one contact/careers page for better addresses
            m = re.search(r'href="([^"]*(?:contact|career|join)[^"]*)"', html, re.I)
            if m and len(emails) < 2:
                try:
                    sub = m.group(1)
                    sub_url = sub if sub.startswith("http") else urllib.parse.urljoin(site, sub)
                    _, page2 = _fetch(sub_url)
                    emails = list(dict.fromkeys(emails + _emails_from(page2)))[:3]
                except Exception:
                    pass
            o["emails"] = ", ".join(emails) if emails else "None published - use careers page / LinkedIn"
            hits += 1
        else:
            o["website"] = ""
            o["emails"] = "Website not confirmed - use the search links"
        if k % 5 == 0 or k == len(targets):
            prog.set(base + span * k / max(1, len(targets)), f"Finding websites & emails ({k}/{len(targets)})")
            log(f"  Websites/emails {k}/{len(targets)} checked ({hits} sites confirmed)")
    for o in companies:
        o.setdefault("website", "")
        o.setdefault("emails", "Not checked (outside top matches)")


def _outreach_drafts(provider, api_key, model, profile, companies, log, prog, n=10, base=90, span=6):
    """Speculative-application email per top company."""
    targets = [o for o in sorted(companies, key=lambda x: -x.get("score", 0))
               if o.get("band") in ("High", "Medium")][:n]
    if _use_demo(provider):
        for o in targets:
            o["outreach"] = {
                "subject": f"Speculative application - experienced BA/PM for {o['name']}",
                "message": (f"Dear Hiring Team at {o['name']},\n\n[DEMO DRAFT - connect a real LLM for a "
                            "tailored message]\n\nI am writing to ask whether you have upcoming needs in "
                            "business analysis / IT project delivery. My background maps closely to your "
                            "sector, and I can share my CV and references immediately.\n\nKind regards,\n[Your name]")}
        log(f"  Outreach drafts (demo templates): {len(targets)}")
        return
    for k, o in enumerate(targets, 1):
        user = f"""Candidate profile: {json.dumps({k2: profile.get(k2) for k2 in ('summary', 'strengths')}, ensure_ascii=False)}

Sponsor company: {o['name']} ({o.get('town', '')}). Likely business (from name): {o.get('why', '')}.
They may have NO advert right now - this is a SPECULATIVE application email.

Write a speculative application email in British English, first person, 130-170 words:
- open with why THIS company specifically (their likely work), not flattery
- 2-3 concrete, quantified capabilities from the CV that map to their business
- one candid closing line that the writer would require Skilled Worker sponsorship and is
  available immediately in London
- no placeholders except [Your name]
Return JSON: {{"subject": "...", "message": "..."}}"""
        try:
            o["outreach"] = extract_json(chat(provider, api_key, model, SYSTEM, user,
                                              max_tokens=900, json_mode=True))
        except Exception as e:
            o["outreach"] = {"subject": "", "message": f"(generation failed: {str(e)[:80]})"}
        prog.set(base + span * k / max(1, len(targets)), f"Drafting outreach ({k}/{len(targets)})")
        log(f"  Outreach draft {k}/{len(targets)}")


def _sponsor_cv_advice(provider, api_key, model, profile, companies, log):
    if _use_demo(provider):
        return ["Demo mode: connect a real LLM (free Gemini key) for tailored positioning advice.",
                "Lead your CV headline with the sector words sponsors search for: energy retrofit, ERP, AI customer service.",
                "Add a one-line right-to-work statement so sponsors know the ask upfront."]
    tops = [f"- {o['name']}: {o.get('why', '')}" for o in companies if o.get("band") == "High"][:12]
    user = f"""Candidate profile: {json.dumps({k: profile.get(k) for k in ('summary', 'strengths')}, ensure_ascii=False)}

Strongest-fit licensed sponsor companies found today:
{chr(10).join(tops) or '(none)'}

Return JSON: {{"advice": ["6-8 CV changes, ordered by impact, that would make THIS candidate more
attractive specifically to these sponsor companies for speculative applications; each <=25 words"]}}"""
    try:
        data = extract_json(chat(provider, api_key, model, SYSTEM, user, max_tokens=900, json_mode=True))
        return [str(a) for a in data.get("advice", [])][:10]
    except Exception as e:
        log(f"  ! CV advice failed ({str(e)[:80]})")
        return []


def run_scan(params, log, prog):
    out_dir = params.get("out_dir") or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
    os.makedirs(out_dir, exist_ok=True)
    demo = bool(params.get("demo"))
    provider = "Demo (offline)" if demo else params["provider"]

    prog.set(4, "Reading your CV")
    log("STEP 1/6 - Reading your CV...")
    cv_text = resume.read_resume(params["resume_path"])
    prog.set(10, "Understanding your profile")
    log("STEP 2/6 - Building your profile with the LLM...")
    profile = build_profile(provider, params.get("api_key", ""), params.get("model", ""), cv_text, log)

    prog.set(18, "Choosing sector keywords")
    log("STEP 3/6 - Choosing sector keywords for the register search...")
    keywords = _keywords_from_llm(provider, params.get("api_key", ""), params.get("model", ""), profile, log)
    extra = [k.strip().lower() for k in (params.get("extra_keywords") or "").split(",") if len(k.strip()) >= 4]
    keywords = list(dict.fromkeys(extra + keywords))

    prog.set(26, "Loading the GOV.UK sponsor register")
    log("STEP 4/6 - Loading the official GOV.UK register of licensed sponsors...")
    orgs = _load_orgs(demo, os.path.join(out_dir, ".cache"), log)
    prog.set(40, "Filtering companies by your sectors")
    items = _filter_orgs(orgs, keywords, params.get("location", "London"),
                         int(params.get("max_companies") or 60), log)
    if not items:
        raise RuntimeError("No sponsor companies matched your sector keywords. "
                           "Add your own keywords in the box and run again.")

    prog.set(45, "Scoring companies against your CV")
    log("STEP 5/6 - Scoring company relevance against your CV...")
    _score_companies(provider, params.get("api_key", ""), params.get("model", ""),
                     profile, items, log, prog)
    companies = [o for o, _ in items]

    log("STEP 5b - Checking which companies have live adverts right now (Adzuna)...")
    if demo:
        for i, o in enumerate(companies):
            o["live"] = "YES - 3 live advert(s) [demo]" if i % 3 == 0 else "None found today - apply speculatively [demo]"
        prog.set(78, "Demo live-jobs flags set")
    else:
        _live_ads(params.get("adzuna_app_id", ""), params.get("adzuna_app_key", ""), companies, log, prog,
                  base=70, span=8)

    log("STEP 5c - Finding company websites and public contact emails...")
    if demo:
        for i, o in enumerate(companies):
            o["website"] = "https://www.example-company.co.uk" if i % 2 == 0 else ""
            o["emails"] = "careers@example-company.co.uk [demo]" if i % 2 == 0 else "Website not confirmed - use the search links"
        prog.set(88, "Demo contact details set")
    else:
        _enrich_contacts(companies, log, prog, base=78, span=10)

    log("STEP 5d - Drafting speculative outreach emails for the top matches...")
    _outreach_drafts(provider, params.get("api_key", ""), params.get("model", ""),
                     profile, companies, log, prog)
    prog.set(95, "Writing CV positioning advice")
    advice = _sponsor_cv_advice(provider, params.get("api_key", ""), params.get("model", ""),
                                profile, companies, log)

    for o in companies:
        q = urllib.parse.quote(f'"{o["name"]}" careers')
        o["careers_link"] = f"https://www.google.com/search?q={q}"
        o["linkedin_link"] = ("https://www.linkedin.com/search/results/companies/?keywords="
                              + urllib.parse.quote(o["name"]))
        o["routes_txt"] = "; ".join(sorted(o.get("routes", []))) or "Worker (see register)"
        o["ratings_txt"] = "; ".join(sorted(o.get("ratings", []))) or "-"

    prog.set(96, "Writing the Excel workbook")
    log("STEP 6/6 - Writing the sponsor-companies Excel...")
    import datetime as dt
    meta = {"run_date": dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "llm": "Demo (offline keyword engine)" if demo else f"{provider} ({params.get('model') or 'default'})",
            "keywords": ", ".join(keywords),
            "location": params.get("location", "London")}
    out_path = os.path.join(out_dir, f"JobScout_Sponsors_{dt.date.today().isoformat()}.xlsx")
    excel.build_sponsor_workbook(out_path, profile, companies, meta, advice)
    high = sum(1 for o in companies if o.get("band") == "High")
    med = sum(1 for o in companies if o.get("band") == "Medium")
    low = sum(1 for o in companies if o.get("band") == "Low")
    live = sum(1 for o in companies if str(o.get("live", "")).startswith("YES"))
    prog.summary(high=high, medium=med, low=low, total=len(companies), live=live, file=out_path)
    prog.set(100, "Done")
    log(f"DONE - {len(companies)} sponsor companies: {high} strong fit, {med} possible, {low} weak; "
        f"{live} advertising right now. Excel saved to:")
    log(f"  {out_path}")
    return out_path
