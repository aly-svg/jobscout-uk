"""Read a CV from PDF, DOCX or TXT into plain text."""
import os


class ResumeError(Exception):
    pass


def read_resume(path: str) -> str:
    if not path or not os.path.exists(path):
        raise ResumeError("Resume file not found. Please upload your CV.")
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".pdf":
            text = _read_pdf(path)
        elif ext in (".docx", ".doc"):
            text = _read_docx(path)
        elif ext in (".txt", ".md"):
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        else:
            raise ResumeError(f"Unsupported file type '{ext}'. Use PDF, DOCX or TXT.")
    except ResumeError:
        raise
    except Exception as e:
        raise ResumeError(f"Could not read the resume ({type(e).__name__}: {e})")

    text = "\n".join(line.strip() for line in text.splitlines())
    text = text.strip()
    if len(text) < 200:
        raise ResumeError(
            "Very little text was extracted from this file. If it is a scanned/image PDF, "
            "export your CV as a text-based PDF or DOCX and try again."
        )
    return text


def _read_pdf(path: str) -> str:
    import pdfplumber

    parts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            parts.append(page.extract_text() or "")
    return "\n".join(parts)


def _read_docx(path: str) -> str:
    import docx

    d = docx.Document(path)
    parts = [p.text for p in d.paragraphs]
    for table in d.tables:
        for row in table.rows:
            parts.append(" | ".join(c.text for c in row.cells))
    return "\n".join(parts)
